Class: MapGraph
Modifications made to MapGraph (what and why):
Implementation done for the empty methods and BFS algorithm.

Class name: GraphAdjList
Purpose and description of class:
Adjacency list is the chosen strategy to represent the graph. 
The graph is encapsulated and managed by GraphAdjList. MapGraph
accesses and manipulates the graph through the instance of this 
class.

Class name: GraphUtil
Purpose and description of class:
The class contains static utility methods.